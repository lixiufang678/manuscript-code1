rm(list = ls())
options(stringsAsFactors = F)

library(tibble)
library(ggplot2)
library(ggpubr)
library(ggthemr)
library(survival)
library(survminer)
library(ggquickeda)
group <- as.data.frame(data.table::fread('TMB/group.txt'))
TMB <- as.data.frame(data.table::fread('TMB/TMB.txt'))
time <- as.data.frame(data.table::fread('TMB/time.txt'))

TMB <- TMB[!TMB$id=='TCGA-2W-A8YY',]
time$futime <- time$futime/12
xx <- merge(TMB,group,by=1)

# 两组间TMB比较
ggplot(xx,aes(Group,TMB)) +
  geom_boxplot(aes(color=Group), outlier.colour = NA, size=1, fill=NA) +
  geom_jitter(aes(fill=Group,color=Group), width = 0.25, shape=21, size=2, alpha=0.7) +
  stat_compare_means(method = 't.test',  label.x = 1.9,size=5) +
  theme_bw(base_rect_size = 1.5) +
  labs(x=NULL,y='TMB', title = '') +
  theme(legend.position = 'none',
        plot.title = element_text(hjust = 0.5,size = 12),
        axis.title.y = element_text(size = 12,colour = 'black'),
        axis.text.x = element_text(size = 12,colour = 'black'),
        axis.text.y = element_text(size = 12,colour = 'black'),
        axis.ticks = element_line(size = 1),
        panel.grid = element_blank()) +
  scale_color_manual(values = c("#E31A1C","#1F78B4")) +
  scale_fill_manual(values = c("#E31A1C","#1F78B4"))


#两组间生存分析
Cluster <- merge(time,group,by=1)
fit <- survfit(Surv(futime,fustat)~Group,data = Cluster)
ggsurvplot(fit,Cluster,pval = T)
sdf <- survdiff(Surv(futime,fustat)~Group,data = Cluster)
p.val <- 1 - pchisq(sdf$chisq, length(sdf$n) - 1)
if(p.val<0.0001){
  p <- 'P < 0.001'
}else{
  p <- paste0('P = ',round(p.val,3))
}

ggplot(Cluster, aes(time = futime, status = fustat,color=Group)) +
  geom_km(size=1.2) + 
  geom_kmticks()+
  theme_bw(base_rect_size = 1.5)+
  scale_color_manual(values = c("#E31A1C","#1F78B4",'#F6B4A6',"#C95550"))+    #c(pal_npg("nrc", alpha =0.9)(9)[c(1)],pal_npg("nrc", alpha =0.9)(9)[c(2)]))+
  labs(y='Overall survival',x='Time (years)')+
  theme_bw(base_rect_size = 2)+
  annotate('text',x = 0.25,y=0.5,label=paste0('Log-rank\n',p),hjust=0,size=5,fontface = 'italic')+
  ggtitle('KM - plotter')

#四组间生存分析
cc <- ifelse(TMB$TMB>median(TMB$TMB),'H-TMB','L-TMB')
TMB$group <- cc
dd <- merge(TMB,Cluster,by=1)
dd$Cluster <- paste(dd$group,dd$Group,sep = '+')

fit <- survfit(Surv(futime,fustat)~Cluster,data = dd)
ggsurvplot(fit,Cluster,pval = T)
sdf <- survdiff(Surv(futime,fustat)~Group,data = Cluster)
p.val <- 1 - pchisq(sdf$chisq, length(sdf$n) - 1)
if(p.val<0.0001){
  p <- 'P < 0.001'
}else{
  p <- paste0('P = ',round(p.val,3))
}

ggplot(dd, aes(time = futime, status = fustat,color=Cluster)) +
  geom_km(size=1.2) + 
  geom_kmticks()+
  theme_bw(base_rect_size = 1.5)+
  scale_color_manual(values = c("#E31A1C","#1F78B4",'#F6B4A6',"#C95550"))+    #c(pal_npg("nrc", alpha =0.9)(9)[c(1)],pal_npg("nrc", alpha =0.9)(9)[c(2)]))+
  labs(y='Overall survival',x='Time (years)')+
  theme_bw(base_rect_size = 2)+
  annotate('text',x = 0.25,y=0.4,label=paste0('Log-rank\n',p),hjust=0,size=5,fontface = 'italic')
