

#install.packages("ggpubr")
getwd()

library(ggpubr)                    #???ð?
tciaFile="TIDE_ZIJI.txt"                #???????ƴ????ļ?
scoreFile="group.txt"     #m6A???ַ????ļ?
#setwd("D:\\biowolf\\m6aTME\\49.IPS")     #?޸Ĺ???Ŀ¼

#??ȡ???????ƴ????ļ?
ips=read.table(tciaFile, header=T, sep="\t", check.names=F, row.names=1)

#??ȡm6A???ַ????ļ?
score=read.table(scoreFile, header=T, sep="\t", check.names=F, row.names=1)

library(tidyverse)
ips$sample <- rownames(ips)
rownames(ips) <- NULL
ips$sample <-  substr(ips$sample,1,12)
ips <- distinct(ips,sample,.keep_all = T)
rownames(ips) <- ips$sample


#?ϲ?????
sameSample=intersect(row.names(ips), row.names(score))
ips=ips[sameSample, , drop=F]
score=score[sameSample, "group", drop=F]
data=cbind(ips, score)

#???ñȽ???
data$group=factor(data$group, levels=c("Low", "High"))
group=levels(factor(data$group))
comp=combn(group, 2)
my_comparisons=list()
for(i in 1:ncol(comp)){my_comparisons[[i]]<-comp[,i]}

#?????????ƴ??ֽ???ѭ??,?ֱ?????С????ͼ
for(i in colnames(data)[1:(ncol(data)-1)]){
	rt=data[,c(i, "group")]
	colnames(rt)=c("IPS", "group")
	gg1=ggviolin(rt, x="group", y="IPS", fill = "group", 
	         xlab="Group", ylab=i,
	         legend.title="Group",
	         palette=c("#0066FF", "#FF0000"),
	         add = "boxplot", add.params = list(fill="white"))+ 
	         stat_compare_means(comparisons = my_comparisons)
	         #stat_compare_means(comparisons = my_comparisons,symnum.args=list(cutpoints = c(0, 0.001, 0.01, 0.05, 1), symbols = c("***", "**", "*", "ns")),label = "p.signif")
	
	pdf(file=paste0(i, ".pdf"), width=6, height=5)
	print(gg1)
	dev.off()
}


